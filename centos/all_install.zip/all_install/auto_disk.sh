#!/bin/bash
# 自动分区格式化挂载磁盘（暂只适用于新磁盘挂载，磁盘扩容功能未写）

LANG=en_US.UTF-8
setup_path='/data'
if [ $1 != "" ];then
	setup_path=$1;
fi

echo "
+----------------------------------------------------------------------
| Bt-WebPanel Automatic disk partitioning tool
+----------------------------------------------------------------------
| Copyright © 2015-2017  All rights reserved.
+----------------------------------------------------------------------
| Auto mount partition disk to $setup_path
+----------------------------------------------------------------------
"
#磁盘扩容(未写)
disk_expansion(){
    #判断指定目录是否被挂载(备份、卸载)
    isR=`df -P|grep $setup_path`
    # partition_name=
    if [ "$isR" != "" ];then
        #添加备份操作
        
        umount -l $setup_path
    fi
}

#数据盘自动分区
fdiskP(){
	
	for i in `cat /proc/partitions|grep -v name|grep -v ram|awk '{print $4}'|grep -v '^$'|grep -v '[0-9]$'|grep -v 'vda'|grep -v 'xvda'|grep -v 'sda'|grep -e 'vd' -e 'sd' -e 'xvd'`;
	do
		#判断指定目录是否被挂载
		isR=`df -P|grep $setup_path`
		if [ "$isR" != "" ];then
			echo "Error: The $setup_path directory has been mounted."
            echo "$setup_path 目录已经被挂载了."
			return;
		fi
		
		isM=`df -P|grep '/dev/${i}1'`
		if [ "$isM" != "" ];then
            _mount_position = `df -P|grep '/dev/${i}1'|awk '{print $NF}'`
			echo "/dev/${i}1 has been mounted."
            echo "/dev/${i}1 分区已经被挂载到${_mount_position}."
			continue;
		fi
			
		#判断是否存在未分区磁盘
		isP=`fdisk -l /dev/$i |grep -v 'bytes'|grep "$i[1-9]*"`
		if [ "$isP" = "" ];then
				#开始分区
				fdisk /dev/$i << EOF
n
p
1


wq
EOF

			sleep 5
			#检查是否分区成功
			checkP=`fdisk -l /dev/$i|grep "/dev/${i}1"`
			if [ "$checkP" != "" ];then
				#格式化分区
				mkfs.xfs /dev/${i}1
				mkdir $setup_path
				#挂载分区
				sed -i "/\/dev\/${i}1/d" /etc/fstab
				echo "/dev/${i}1    $setup_path    xfs    defaults    0 0" >> /etc/fstab
				mount -a
				df -h
			fi
		else
			#判断是否存在Windows磁盘分区
			isN=`fdisk -l /dev/$i|grep -v 'bytes'|grep -v "NTFS"|grep -v "FAT32"`
			if [ "$isN" = "" ];then
				echo 'Warning: The Windows partition was detected. For your data security, Mount manually.';
				return;
			fi
			
			#挂载已有分区
			checkR=`df -P|grep "/dev/$i"`
			if [ "$checkR" = "" ];then
					[ -d "$setup_path" ] || mkdir -p $setup_path
					sed -i "/\/dev\/${i}1/d" /etc/fstab
					echo "/dev/${i}1    $setup_path    xfs    defaults    0 0" >> /etc/fstab
					mount -a
					df -h
			fi
		fi
        
			
        #清理不可写分区
        echo 'True' > $setup_path/checkD.pl
        if [ ! -f $setup_path/checkD.pl ];then
                #sed -i "/\/dev\/${i}1/d" /etc/fstab
                sed -i "/\/dev\/${i}1/s/^/&#/" /etc/fstab
                mount -a
                df -h
                echo -e "\033[31m测试写入数据失败, 卸载分区/dev/${i}1.\033[0m"
        else
                rm -f $setup_path/checkD.pl
                echo -e "\033[36m测试写入数据成功.\033[0m"
        fi
	done
}


stop_service(){
    sync
	if [ -f "/etc/init.d/nginx" ]; then
		/etc/init.d/nginx stop > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/httpd" ]; then
		/etc/init.d/httpd stop > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/mysqld" ]; then
		/etc/init.d/mysqld stop > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/pure-ftpd" ]; then
		/etc/init.d/pure-ftpd stop > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/tomcat" ]; then
		/etc/init.d/tomcat stop > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/redis" ]; then
		/etc/init.d/redis stop > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/memcached" ]; then
		/etc/init.d/memcached stop > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/phpfpm" ]; then
		/etc/init.d/phpfpm stop > /dev/null 2>&1
	fi
}

start_service(){
	if [ -f "/etc/init.d/nginx" ]; then
		/etc/init.d/nginx start > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/httpd" ]; then
		/etc/init.d/httpd start > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/mysqld" ]; then
		/etc/init.d/mysqld start > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/pure-ftpd" ]; then
		/etc/init.d/pure-ftpd start > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/tomcat" ]; then
		/etc/init.d/tomcat start > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/redis" ]; then
		/etc/init.d/redis start > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/memcached" ]; then
		/etc/init.d/memcached start > /dev/null 2>&1
	fi

	if [ -f "/etc/init.d/php-fpm" ]; then
		/etc/init.d/php-fpm start > /dev/null 2>&1
	fi

	echo "True" > $setup_path/wwwroot/502Task.pl
}

while [ "$go" != 'y' ] && [ "$go" != 'n' ]
do
	read -p "Do you want to try to mount the data disk to the $setup_path directory?(y/n): " go;
done

if [ "$go" = 'n' ];then
	echo -e "Bye-bye"
	exit;
fi

if [ -f /etc/init.d/nginx -o -f /etc/init.d/mysqld ]; then
    echo -e ""
    echo -e "stop service"
    echo -e "准备停止相关服务"
    echo -e ""
    sleep 3
    stop_service
    echo -e ""
    echo -e "disk partition..."
    echo -e "磁盘分区..."
    sleep 2
    fdiskP
    echo -e "start service"
    echo -e "启动相关服务"
    start_service
else
	fdiskP
	echo -e ""
	echo -e "Done"
	echo -e "挂载成功"
fi