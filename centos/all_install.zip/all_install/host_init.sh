#!/bin/sh
#Author: 
#Date:2018-05-25
#Description: 针对Centos7 系统的优化
NEW_HOSTNAME='' #若购买服务器后已修改好主机名，不需赋值
SSH_PORT='9988'
NETWORK_CARD_NAME='' # 若服务器存在网卡超过2块，禁止给该差数赋值
# NETWORK_CARD_NAME='ifcfg-eth0' # 若服务器存在网卡超过2块，禁止给该差数赋值

# The function used to configure yum related operations
yum_config(){
    ## 针对国内使用阿里云yum源
    # /bin/cp /etc/yum.repos.d/CentOS-Base.repo  /etc/yum.repos.d/CentOS-Base.repo.backup
    # wget -O /etc/yum.repos.d/CentOS-Base.repo https://mirrors.aliyun.com/repo/Centos-7.repo
    
    #更新系统
    yum clean all
    yum makecache
#    yum -y update
    #安装扩展源
    yum install -y epel-release
	
    yum install -y wget vim-enhanced rsync net-tools bash-completion bash-completion-extras.noarch lrzsz
}

# The function used to configure firewalld related operations
firewalld_config(){
    # 禁用并关闭selinux
    grep "SELINUX=enforcing" /etc/selinux/config && sed -i 's/SELINUX=enforcing/SELINUX=disabled/' /etc/selinux/config
    setenforce 0
    
    #禁用firewalld
    systemctl stop  firewalld.service
    systemctl disable  firewalld.service
    
    yum install -y iptables-services
    systemctl enable  iptables.service
	iptables -F
	service iptables save
    systemctl restart  iptables.service
}

# The function used to configure disk related operations
disk_config(){
    [ -f auto_disk.sh ] && sh auto_disk.sh || echo -e "\033[31m 磁盘分区脚本未找到,磁盘配置失败\033[0m" >> $0_error.log
    # 挂载tmpfs文件系统
    # mount --bind /dev/shm /tmp
    # grep -q "/dev/shm" /etc/rc.local || echo "/bin/mount --bind /dev/shm /tmp" >> /etc/rc.local
}

# The function used to manage service startup
service_startup_config(){
    service_name='NetworkManager '
    
    for service in service_name;do
        systemctl stop "$service"
        systemctl disable "$service"
    done
}

# The function used to configure ssh related operations
ssh_config(){
    # 修改SSH默认端口
    grep '^Port' /etc/ssh/sshd_config && \
    sed -i "/^Port/s/Port.*/Port ${SSH_PORT}/g" /etc/ssh/sshd_config || \
    sed -i "/^#Port/a\Port ${SSH_PORT}" /etc/ssh/sshd_config
    
    # 优化SSH连接时响应速度 
    sed -i 's/.*UseDNS yes/UseDNS no/' /etc/ssh/sshd_config
    sed -i 's/.*GSSAPIAuthentication yes/GSSAPIAuthentication no/' /etc/ssh/sshd_config
    
    # 禁止空密码用户登录
    grep -q '^PermitEmptyPasswords no' /etc/ssh/sshd_config || \
    sed -i '/^#PermitEmptyPasswords/a\PermitEmptyPasswords no' /etc/ssh/sshd_config

    systemctl restart sshd.service
}

# The function used to configure network related operations
network_config(){
	if [ -n "$NETWORK_CARD_NAME" ];then
		cd /etc/sysconfig/network-scripts
		network_card=`ls ifcfg-*|grep -v 'ifcfg-lo'|head -n 1`
		#更改网卡名操作
		mv ${network_card} ${NETWORK_CARD_NAME}
		grep -q 'net.ifnames=1' /etc/default/grub || \
		sed -i 's#cl/root#cl/root net.ifnames=0 biosdevname=0#' /etc/default/grub
		grub2-mkconfig -o /boot/grub2/grub.cfg
	fi
}

# The function used to configure Kernel parameters related operations
kernel_config(){
    # 阿里云ecs默认有做内核优化，可注释掉/etc/sysctl.conf 修改
    # grep -q "vm.swappiness" /etc/sysctl.conf || cat >> /etc/sysctl.conf << EOF
#######################################
# vm.swappiness = 0
# net.core.rmem_default = 262144
# net.core.rmem_max = 16777216
# net.core.wmem_default = 262144
# net.core.wmem_max = 16777216
# net.core.somaxconn = 262144
# net.core.netdev_max_backlog = 262144
# net.ipv4.tcp_max_orphans = 262144
# net.ipv4.tcp_max_syn_backlog = 262144
# net.ipv4.tcp_max_tw_buckets = 10000
# net.ipv4.ip_local_port_range = 1024 65500
# net.ipv4.tcp_tw_recycle = 1
# net.ipv4.tcp_tw_reuse = 1
# net.ipv4.tcp_syncookies = 1
# net.ipv4.tcp_synack_retries = 1
# net.ipv4.tcp_syn_retries = 1
# net.ipv4.tcp_fin_timeout = 30
# net.ipv4.tcp_keepalive_time = 1200
# net.ipv4.tcp_mem = 786432 1048576 1572864
# fs.aio-max-nr = 1048576
# fs.file-max = 6815744
# kernel.sem = 250 32000 100 128
# fs.inotify.max_user_watches = 1048576
# EOF
    # sysctl -p
    
    # ##优化文件打开数，最大进程数, 最大栈大小
    # grep -q "* - nofile" /etc/security/limits.conf || cat >> /etc/security/limits.conf << EOF
#######################################
# * soft nofile 65535
# * hard nofile 65535
# * - nproc  65536
# * - stack  1024
# EOF
 
    grep -q "ulimit -n" /etc/profile || cat >> /etc/profile << EOF
#######################################
# ulimit -n 65535
# ulimit -u 65536
# ulimit -s 1024
 
alias grep='grep --color=auto'
export HISTTIMEFORMAT="%Y-%m-%d %H:%M:%S "
EOF
}

# Other system operations
host_other_config(){
    [ -n "$NEW_HOSTNAME" ] && hostnamectl set-hostname "$NEW_HOSTNAME"
    # 脚本目录加入PATH环境变量
    grep -q "/usr/local/sbin" $HOME/.bash_profile || cat >> $HOME/.bash_profile << EOF
########################################
export PATH=/usr/local/sbin:\$PATH
EOF
    
    # 常用命令做别名
    sed -i "/mv/a\alias cdnginx='cd /usr/local/nginx/conf/vhosts'" $HOME/.bashrc
    sed -i "/mv/a\alias cknginx='/usr/local/nginx/sbin/nginx -t'" $HOME/.bashrc
    sed -i "/mv/a\alias cdsbin='cd /usr/local/sbin'" $HOME/.bashrc
}

main(){
    if [ $(whoami) = 'root' ];then 
        yum_config
        ssh_config
        disk_config
        kernel_config
        host_other_config
        # #非阿里云服务器初始化时需执行的部分函数
        # firewalld_config
        # service_startup_config
        # network_config
    else 
        echo -e '\033[31mPlease switch to root user operation!\033[0m'
    fi
}

main

#内核优化
echo 'net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_syncookies = 1' > /etc/sysctl.conf

#最大文件数优化
sed -ni "s#65535#1000000#g"p /etc/security/limits.conf

echo 'export PS1="[\[\033[01;32m\]\u@\h\[\033[00m\] \[\033[01;34m\]\W\[\033[00m\]]\\$"' >> /etc/profile