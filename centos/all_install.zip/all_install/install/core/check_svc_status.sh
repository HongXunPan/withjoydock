#!/bin/bash
#Description: 服务检测脚本

##check last command is OK or not.
check_ok() {
    if [ $? != 0 ]
    then
        echo "Error, Check the error log."
        exit 1
    fi
}

# 打印信息
function print_messages() {
    msg=$1
	if [ "$#" -gt 1 ];then
        other_msg=$2
    fi
	
	if [ $? -eq 0 ];then
        echo -e "\e[36msuccessful\t${msg}\e[0m"
    else
        echo -e "\e[31mFail\t${msg}\n\t${other_msg}\e[0m"
    fi
}

# 检测redis服务是否正常
function check_redis_status() {
    for p in `seq ${redis_start_port} ${redis_end_port}`;do
        echo "keys *"|redis-cli -h ${db_addr} -p ${p}
        print_messages "测试连接redis $p" "请手动尝试连接:redis-cli -h ${db_addr} -p ${p}"
    done
    check_ok
}

# 检测mysql服务是否正常
function check_mysql_status() {
    echo "show databases;"| mysql -h 127.0.0.1 -u root -p ${mysql_pwd}
    print_messages "测试连接mysql" "请手动尝试连接:mysql -h 127.0.0.1 -u root -p "
}

# 检测memcached服务是否正常
function check_memcached_status() {
    yum install -y nc
    for p in `seq ${redis_start_port} ${redis_end_port}`;do
        printf "set test_key1 0 30 2\r\n22\r\n"|nc ${db_addr} $p
        printf "get test_key1\r\n"|nc ${db_addr} $p
        print_messages "测试连接memcached" "请手动尝试连接:echo stats | nc ${db_addr} $p"
    done
    check_ok
}


# 检测服务进程是否存在
function check_process_exists() {
    p_name="$1"
    p_number=`ps aux |grep ${p_name}|grep -v grep| wc -l`
	if [ ${p_number} -lt 1 ];then
        echo -e "\e[31m Error: ${p_name} prrocess doesn't exist\e[0m"
        exit 1
	else
        echo -e "\e[36m Successful: ${p_name} prrocess started.\e[0m"
    fi
}

