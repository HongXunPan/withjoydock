#!/bin/bash

##function of install six memcached
install_memcached()
{
    cd $install_basedir
    for p in  gcc libevent-devel memcached nc libmemcached;do
        myum $p
    done
    
    if ! grep -q "^$memcached_user:" /etc/passwd;then
        useradd -M -s /sbin/nologin $memcached_user
    fi
    /bin/cp ./src/memcached-1.5.6.tar.gz /usr/local/src/
    cd /usr/local/src
    [ -f memcached-1.5.6.tar.gz ]||wget  http://www.memcached.org/files/memcached-1.5.6.tar.gz
    tar -zxvf  memcached-1.5.6.tar.gz
    cd   memcached-1.5.6
    ./configure --prefix=${memcached_install_dir}
    make &&  make install
    [ -d "${memcached_install_dir}/logs" ] || mkdir -p ${memcached_install_dir}/logs
    chown -R memcached.memcached ${memcached_install_dir}
	
	# 配置第一个memcached
    chmod 755 ${install_basedir}/conf/memcached11211
    /bin/cp  ${install_basedir}conf/memcached11211  /etc/init.d/memcached${memcached_start_port}
    sed -i "s/CACHESIZE=128/CACHESIZE=${memcached_mem_size}/g" /etc/init.d/memcached${memcached_start_port}
    chkconfig  --add memcached${memcached_start_port}
    chkconfig  --level 2345 memcached${memcached_start_port} on
    service memcached${memcached_start_port} restart
	
	
    #开始配置其他memcached
    if [ ${memcached_initialize_number} -gt 1 ];then
        start_number=`expr ${memcached_start_port} + 1`  #默认的话是11211+1
        for mem_port in `seq ${start_number} ${memcached_end_port}`;do
            /bin/cp  ${install_basedir}conf/memcached11211  /etc/init.d/memcached${mem_port}
            sed -i -e "s/11211/${mem_port}/g" -e "s/CACHESIZE=128/CACHESIZE=${memcached_mem_size}/g" \
			/etc/init.d/memcached${mem_port}
            
            chkconfig  --add memcached${mem_port}
            chkconfig  --level 2345 memcached${mem_port} on
            service memcached${mem_port} restart
        done
    fi
    check_ok
    check_memcached_status
}
