#!/bin/bash

##function of intsall mysql.
install_mysql() {
    data_dir='/data/mysql'
    ar=`arch`
    cd $install_basedir
    echo -e "\033[36mInstall mysql.\033[0m\n"
    if ! grep '^mysql:' /etc/passwd;then
        useradd -M mysql -s /sbin/nologin
    fi
    myum compat-libstdc++-33
    /bin/cp ./src/mysql-5.6.44-linux-glibc2.12-$ar.tar.gz /usr/local/src
    cd /usr/local/src
    [ -f mysql-5.6.44-linux-glibc2.12-$ar.tar.gz ] || wget https://dev.mysql.com/get/Downloads/MySQL-5.6/mysql-5.6.44-linux-glibc2.12-x86_64.tar.gz
    tar zxf  mysql-5.6.44-linux-glibc2.12-x86_64.tar.gz
    check_ok
    [ -d /usr/local/mysql ] && /bin/mv /usr/local/mysql /usr/local/mysql_bak
    mv mysql-5.6.44-linux-glibc2.12-x86_64   /usr/local/mysql
    [ -d ${data_dir} ] && /bin/mv ${data_dir} ${data_dir}_bak
    mkdir -p ${data_dir}
    chown -R mysql:mysql ${data_dir}
    cd /usr/local/mysql
    ./scripts/mysql_install_db --user=mysql --datadir=${data_dir}
    check_ok
	# 拷贝主配置文件
	/bin/cp ${install_basedir}conf/${mysql_conf} /etc/my.cnf
    check_ok
    #检测初始化生成的ibdata1文件大小
    innodb_data_size=$(du -sh ${data_dir}/ibdata1 |awk '{print $1}')
    _innodb_data_size=$(cat /etc/my.cnf|grep ibdata1|awk -F '=|:|;|'  '{print $3}')
    sed -i "s/ibdata1:${_innodb_data_size}/ibdata1:${innodb_data_size}/" /etc/my.cnf
    /bin/cp -f support-files/mysql.server /etc/init.d/mysqld
    chmod 755 /etc/init.d/mysqld
    chkconfig --add mysqld
    check_ok
    chkconfig mysqld on
    /etc/init.d/mysqld start
#    rm -f ${data_dir}/ib*  #为解决启动报错问题
    echo "export PATH=\$PATH:/usr/local/mysql/bin" >> /etc/profile.d/path.sh
    source /etc/profile.d/path.sh
    yum remove mysql -y

    # ----------------- 未执行成功(已修复待测试) -----------------------
    mysql -e "update mysql.user set password=password('${mysql_pwd}') where user.user='root';"
    # mysql -e "grant all on *.* to 'root'@${pma_web_addr} identified by '$mysql_pwd';"
    # mysql -e "UPDATE mysql.user SET Grant_priv = 'Y' WHERE user.Host = '${pma_web_addr}' AND user.User = 'root';"
    mysql -e "drop user ''@'${hostname}';"
    # ---------------------------------------------------
    mysql -e "CREATE USER '${business_user}'@'${business_auth_host}' IDENTIFIED WITH mysql_native_password;"
    mysql -e "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, FILE, INDEX, ALTER, CREATE TEMPORARY TABLES, CREATE VIEW, EVENT, TRIGGER, SHOW VIEW, CREATE ROUTINE, ALTER ROUTINE, EXECUTE ON *.* TO '${business_user}'@'${business_auth_host}' REQUIRE NONE WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0;"
    mysql -e "update mysql.user set password=password('${business_pwd}') where user.user ='${business_user}' and user.host = '${business_auth_host}';"
    mysql -e "drop user '';"
    mysql -e "drop user ''@'localhost';"
    mysql -e "drop user 'root'@'${hostname}';"
    mysql -e "DROP DATABASE test;"
    mysql -e "DROP DATABASE data;"
    mysql -e "flush privileges;"
}
