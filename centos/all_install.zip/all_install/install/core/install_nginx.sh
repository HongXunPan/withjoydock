#!/bin/bash
# Nginx配置

# 删除nginx虚拟主机配置文件中 ssl配置的注释
function remove_ssl_comment(){
    domain="$1"
    cd ${nginx_install_dir}/conf/vhosts/
    file_name=`grep ${domain} ./*|head -n1 |awk -F ':|/' '{print $2}'`

    sed -i -e "s/ssl_file_name.crt/1_${domain}_bundle.crt/" \
    -e "s/ssl_file_name.key/2_${domain}.key/" \
    -e "/listen\s\+443\s\+ssl/s/#//g" -e "/ssl_\w\+/s/#//g" \
    ${nginx_install_dir}/conf/vhosts/${file_name}
}

# 项目对应多个域名时生成nginx配置的函数
function other_nginx_conf_create(){
    if [ "$#" -lt 2 ];then
        echo "\033[31mError: 运行$0,至少需要俩个参数\033[0m"
        exit 1
    fi
	
    domain_array="$1"
    config_file="$2"
    ssl_status="$3"		# 区分域名数组是否为需要开启ssl的
	
    if [ ! -f ${config_file} ];then
        echo "\033[31mError: nginx虚拟主机模板文件不存在, 其他域名配置创建失败\033[0m"
        exit 1
    fi
    
    # 判断是否开启ssl配置
    if [ ${ssl_status} = 'on' ];then

        # ssl证书名称格式已腾讯云申请的ssl证书的名称格式做模板
        for domain in ${domain_array[@]};do
            cd ${nginx_install_dir}/conf/vhosts
            cp ${config_file} ./${domain}.conf
            remove_ssl_comment ${domain}
            sed -i -e "s/DOMAIN/${domain}/g" \
            -e "s/access\.log/${domain}.access.log/g" ${nginx_install_dir}/conf/vhosts/${domain}.conf
        done
    else
        for domain in ${domain_array[@]};do
        	cd ${nginx_install_dir}/conf/vhosts
        	cp ${config_file} ./${domain}.conf
        	sed -i -e "s/DOMAIN/${domain}/g" \
        	-e "s/access\.log/${domain}.access.log/g" ${nginx_install_dir}/conf/vhosts/${domain}.conf
        done
    fi
}


##function of install nginx.
install_nginx() 
{
    yum install -y psmisc svn   #svn用于开发人员部署c++项目
    cd $install_basedir
    for p in pcre-devel zlib-devel openssl-devel openssl;do
        myum $p
    done
    if ! grep -q "^$nginx_user:" /etc/passwd;then
        useradd -s /sbin/nologin $nginx_user
    fi
    [ -d "$web_root_dir" ] || mkdir -pv $web_root_dir
    /bin/cp ./src/nginx-1.14.2.tar.gz /usr/local/src/
    cd /usr/local/src
    [ -f nginx-1.14.2.tar.gz ] || wget https://nginx.org/download/nginx-1.14.2.tar.gz
    tar -zxvf nginx-1.14.2.tar.gz
    check_ok
    cd nginx-1.14.2
    ##隐藏nginx版本信息
    sed -i 's/\#define NGINX_VERSION      "1.14.2"/\#define NGINX_VERSION      "7.0"/' ./src/core/nginx.h
    sed -i "s/\#define NGINX_VER          \"nginx\/\"/#define NGINX_VER          \"$cp_name\/\"/" ./src/core/nginx.h
    sed -i "s/\#define NGINX_VAR          \"NGINX\"/\#define NGINX_VAR          \"$cp_name\"/" ./src/core/nginx.h
    sed -i "/ngx_http_server_string\[\] =/s/nginx/$cp_name/" src/http/ngx_http_header_filter_module.c
    sed -i "/full_string\[\]/s/Server\: /Server\: $cp_name/" src/http/ngx_http_header_filter_module.c
    sed -i "/NGINX_VER/s/<\//\(http\:\/\/$domain\)<\//" src/http/ngx_http_special_response.c
    sed -i "/<hr><center>nginx/s/<hr><center>nginx/<hr><center>$cp_name/" src/http/ngx_http_special_response.c
    ./configure \
    --prefix=${nginx_install_dir} \
    --user=$nginx_user \
    --group=$nginx_user \
    --with-http_stub_status_module \
    --with-http_ssl_module \
    --with-pcre \
    --without-http-cache \
    --with-http_realip_module
    check_ok
    make && make install
    check_ok
    if [ -f /etc/init.d/nginx ]
    then
        /bin/mv /etc/init.d/nginx  /etc/init.d/nginx_`date +%s`
    fi
    /bin/cp ${install_basedir}conf/nginx_init /etc/init.d/nginx
    check_ok
    chmod 755 /etc/init.d/nginx
    chkconfig --add nginx
    chkconfig nginx on
    [ -d "${nginx_install_dir}"/conf/ssl ] || mkdir -p ${nginx_install_dir}/conf/ssl
    ## ssl证书拷贝
    /usr/bin/cp  ${install_basedir}conf/ssl/* ${nginx_install_dir}/conf/ssl/
	
    ##nginx主配置文件
    /bin/cp ${install_basedir}conf/nginx.conf  ${nginx_install_dir}/conf/
    sed -i "1s/www/$nginx_user/g" ${nginx_install_dir}/conf/nginx.conf
    sed -i "s#/usr/local/nginx#${nginx_install_dir}#g" ${nginx_install_dir}/conf/nginx.conf
    # sed -i "s/cp_name/$cp_name/g" ${nginx_install_dir}/conf/nginx.conf
    check_ok
    [ -d ${nginx_install_dir}/conf/vhosts ] || mkdir -pv ${nginx_install_dir}/conf/vhosts
    [ -d ${web_dir} ] || mkdir -p ${web_dir}
    chmod g+s ${web_dir}
	
    ##nginx默认虚拟主机配置
    cat > ${nginx_install_dir}/conf/vhosts/default.conf <<-EOF
	server
	{
	    listen 80 default_server;
	    listen 443 ssl default_server;
	    server_name localhost;
	    index index.html index.htm index.php;
	    root /tmp/1233;
	    deny all;
	    ssl_certificate ssl/default.crt;
	    ssl_certificate_key ssl/default.key;
	    access_log off;
	}
	EOF
    
	
    # 后期可以把针对nginx的配置操作，分项目单独封装模块
    # 官网虚拟主机配置修改
    cp ${install_basedir}conf/nginx_vhost.conf ${nginx_install_dir}/conf/vhosts/${web_item_name}.conf
    sed -i -e "s/DOMAIN/${domain}/g" -e "s#web_root_dir#${web_root_dir}#g" -e "s/access\.log/${domain}.access.log/g" \
    ${nginx_install_dir}/conf/vhosts/${web_item_name}.conf
    [ -n "$web_item_listen_port" ] && sed -i "/^\s\+/s/listen\s\+[^ssl]*;/listen       ${web_item_listen_port};/g" \
    ${nginx_install_dir}/conf/vhosts/${web_item_name}.conf
	# 创建通用的多域名nginx配置
	# 需要安装ssl时还要传第三个位置参数'on' 进去
    [ ${#api_other_domain[@]} -ge 1 ] && other_nginx_conf_create ${api_other_domain} ${install_basedir}conf/nginx_vhost.conf

 
    # cdn虚拟主机配置
    if [ -n "$cdn_domain" ];then #判断代理商系统包名变量是否不为空
        mkdir -p ${web_dir}cdnsource
        chown -R ${nginx_user}.${nginx_user} ${web_root_dir}
        /bin/cp ${install_basedir}conf/cdnsource.conf  ${nginx_install_dir}/conf/vhosts/
        sed -i -e "s/DOMAIN/${cdn_domain}/g" -e "s#/data/wwwroot/cdnsource#${cdn_root_dir}#g" \
        -e "s/access\.log/${cdn_domain}.cdn.access.log/g" ${nginx_install_dir}/conf/vhosts/cdnsource.conf
        [ -n "$cdn_item_listen_port" ] && sed -i "/^\s\+/s/listen\s\+[^ssl]*;/listen       ${cdn_item_listen_port};/g" \
        ${nginx_install_dir}/conf/vhosts/cdnsource.conf
    else
        /bin/cp ${install_basedir}conf/cdnsource.conf  ${nginx_install_dir}/conf/vhosts/cdnsource.conf.bak
    fi
    
    # 代理商系统虚拟主机配置修改
    if [ -n "$agency_item_name" ];then #判断代理商系统包名变量是否不为空
        cp ${install_basedir}conf/agency.conf  ${nginx_install_dir}/conf/vhosts/${agency_item_name}.conf
        sed -i -e "s/DOMAIN/${agency_domain}/g"  -e "s#agency_root_dir#${agency_root_dir}#g" \
        -e "s/access\.log/${agency_domain}.access.log/g" ${nginx_install_dir}/conf/vhosts/${agency_item_name}.conf
        [ -n "$agency_item_listen_port" ] && sed -i "/^\s\+/s/listen\s\+[^ssl]*;/listen       ${agency_item_listen_port};/g" \
        ${nginx_install_dir}/conf/vhosts/${agency_item_name}.conf
    fi

    # h5项目虚拟主机配置修改
    # 创建针对H5系统的多域名nginx配置; 
    if [ -n "$h5_item_name" ];then #判断代理商系统包名变量是否不为空
        cp ${install_basedir}conf/h5.conf  ${nginx_install_dir}/conf/vhosts/${h5_item_name}.conf
        sed -i -e "s/DOMAIN/${h5_domain}/g"  -e "s#h5_root_dir#${h5_root_dir}#g" \
        -e "s/access\.log/${h5_domain}.h5.access.log/g" ${nginx_install_dir}/conf/vhosts/${h5_item_name}.conf
        [ -n "$h5_item_listen_port" ] && sed -i "/^\s\+/s/listen\s\+[^ssl]*;/listen       ${h5_item_listen_port};/g" \
        ${nginx_install_dir}/conf/vhosts/${h5_item_name}.conf
        
		# 需要安装ssl时还要传第三个位置参数'on' 进去
        [ ${#h5_other_domain[@]} -ge 1 ] && other_nginx_conf_create ${h5_other_domain} ${install_basedir}conf/h5.conf
    fi

    # 后台项目虚拟主机配置修改
    if [ -n "$backstage_item_name" ];then #判断代理商系统包名变量是否不为空
        cp ${install_basedir}conf/backstage.conf  ${nginx_install_dir}/conf/vhosts/${backstage_item_name}.conf
        sed -i -e "s/DOMAIN/${backstage_domain}/g"  -e "s#backstage_root_dir#${backstage_root_dir}#g" \
        -e "s/access\.log/${backstage_domain}.backstage.access.log/g" ${nginx_install_dir}/conf/vhosts/${backstage_item_name}.conf
        [ -n "$backstage_item_listen_port" ] && sed -i "/^\s\+/s/listen\s\+[^ssl]*;/listen       ${backstage_item_listen_port};/g" \
        ${nginx_install_dir}/conf/vhosts/${backstage_item_name}.conf
    fi
	
    # 拷贝转发wss协议配置文件
    if [ -n "$forward_wss_domain" ];then
        cp ${install_basedir}conf/forward_wss.conf  ${nginx_install_dir}/conf/vhosts/forward_wss.conf
        sed -i "s/DOMAIN/${forward_wss_domain}/g" ${nginx_install_dir}/conf/vhosts/forward_wss.conf
    else
        cp ${install_basedir}conf/forward_wss.conf  ${nginx_install_dir}/conf/vhosts/forward_wss.conf.bak
    fi


    # 移除ssl注释
    if [ ${#ssl_domain[@]} -ge 1 ];then
        for ssl_name in ${ssl_domain[@]};do
            remove_ssl_comment   ${ssl_name}
        done
    fi

    
    # echo "export PATH=\$PATH:${nginx_install_dir}/sbin" >> /etc/profile.d/path.sh
    # 添加命令别名
    grep -q 'cdnginx' /root/.bashrc || echo "alias cdnginx='cd /usr/local/nginx/conf/vhosts'" >> /root/.bashrc
    grep -q 'cknginx' /root/.bashrc || echo "alias cknginx='/usr/local/nginx/sbin/nginx -t'" >> /root/.bashrc
    source /etc/profile
    source /root/.bashrc
    #针对游戏c++项目代码部分操作
    mkdir -p ${gs_code_dir}
    #Create GameSever project user.
    grep -qw 'server' /etc/passwd || useradd -s /sbin/nologin server

    service nginx restart
    check_ok
    check_process_exists 'nginx'
}
