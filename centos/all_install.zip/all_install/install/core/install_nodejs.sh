#!/bin/bash

##function of intsall node.js.
install_nodejs() 
{
    cd /usr/local/src
    [ -f node-v10.14.2-linux-x64.tar.xz ] || wget https://nodejs.org/dist/v10.14.2/node-v10.14.2-linux-x64.tar.xz
    tar -Jxvf node-v10.14.2-linux-x64.tar.xz
    mv node-v10.14.2-linux-x64 /usr/local/node
    echo "export PATH=\$PATH:/usr/local/node/bin" >> /etc/profile.d/path.sh
}