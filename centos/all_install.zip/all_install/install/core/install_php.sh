#!/bin/bash


##function of install php-fpm
install_phpfpm()
{
    cd $install_basedir
    echo -e "Install php.\n"
    /bin/cp ./src/php-5.6.39.tar.gz /usr/local/src/
    cd /usr/local/src
	
    [ -f php-5.6.39.tar.gz ] || wget -O php-5.6.39.tar.gz http://cn2.php.net/get/php-5.6.39.tar.gz/from/this/mirror
    tar zxf php-5.6.39.tar.gz &&   cd php-5.6.39
    for p in  openssl-devel bzip2-devel \
    libxml2-devel curl-devel libpng-devel \
    libjpeg-devel freetype-devel libmcrypt-devel \
    libtool-ltdl-devel perl-devel
    do
        myum $p
    done

    if ! grep -q "^$php_user:" /etc/passwd
    then
        useradd -s /sbin/nologin $php_user
    fi
    check_ok
    ./configure \
    --prefix=${php_install_dir} \
    --with-config-file-path=${php_install_dir}/etc \
    --with-fpm-user=$php_user \
    --with-fpm-group=$php_user \
    --with-mysql \
    --with-pdo-mysql \
    --with-mysqli \
    --with-libxml-dir \
    --with-gd \
    --with-jpeg-dir \
    --with-png-dir \
    --with-freetype-dir \
    --with-iconv-dir \
    --with-zlib-dir \
    --with-mcrypt \
    --enable-sockets \
    --enable-fpm \
    --enable-soap \
    --enable-gd-native-ttf \
    --enable-ftp \
    --enable-mbstring \
    --enable-exif \
    --disable-ipv6 \
    --with-pear \
    --with-curl \
    --with-openssl \
    --enable-pcntl \
    --disable-fileinfo
    ##内存不足1g可能会报错，需要加--disbale-fileinfo
    check_ok
    make && make install
    check_ok
    [ -f ${php_install_dir}/etc/php.ini ] || /bin/cp php.ini-production  ${php_install_dir}/etc/php.ini
    if ${php_install_dir}/bin/php -i |grep -iq 'date.timezone => no value';then
        sed -i '/;date.timezone =$/a\date.timezone = "Asia\/Chongqing"'  ${php_install_dir}/etc/php.ini
    fi
    [ -f ${php_install_dir}/etc/php-fpm.conf ] ||/bin/cp ${install_basedir}conf/php-fpm.conf ${php_install_dir}/etc/
    sed -i "s/user =.*/user = $php_user/g;s/group =.*/group = $php_user/g"  ${php_install_dir}/etc/php-fpm.conf
    check_ok
    [ -f /etc/init.d/phpfpm ] || /bin/cp sapi/fpm/init.d.php-fpm /etc/init.d/phpfpm
    chmod 755 /etc/init.d/phpfpm
    chkconfig phpfpm on
    service phpfpm start
    check_ok
	check_process_exists 'php-fpm'
    echo "export PATH=\$PATH:${php_install_dir}/bin" >> /etc/profile.d/path.sh
    source /etc/profile.d/path.sh
}


##The function of install php extension module
install_php_extension() 
{
    # 该函数最后的sed语句可能有问题需要注意
    mod_name=$1
    ${php_install_dir}/bin/phpize > cache.log
    #DIR=`echo $(cat cache.log |awk -F ':' '/Zend Module/ {print $2}')`
    if [ $mod_name == 'memcached.so' ];then
        ./configure --with-php-config=${php_install_dir}/bin/php-config \
        --with-libmemcached-dir=/usr/local/libmemcached \
        --enable-memcached --disable-memcached-sasl
    else
        ./configure --with-php-config=${php_install_dir}/bin/php-config
    fi
    check_ok
    make && make install
    check_ok
    sed -i "/^\[PHP\]/a\extension = $mod_name" ${php_install_dir}/etc/php.ini
    service phpfpm restart
    unset mod_name
}


##function of install redis extension module
install_php_redismod() 
{
    cd $install_basedir
    /bin/cp ./src/redis-4.0.2.tgz /usr/local/src/
    cd /usr/local/src
    [ -f redis-4.0.2.tgz ]||wget https://pecl.php.net/get/redis-4.0.2.tgz
    check_ok
    tar -zxf redis-4.0.2.tgz
    check_ok
    cd redis-4.0.2
    install_php_extension redis.so
}


##function of install memcached extension module
install_php_memmod() 
{
    cd $install_basedir
    /bin/cp ./src/memcached-2.2.0.tgz /usr/local/src/
    /bin/cp ./src/libmemcached-1.0.18.tar.gz /usr/local/src/
    cd /usr/local/src
    
    [ -f libmemcached-1.0.18.tar.gz ]||wget https://launchpad.net/libmemcached/1.0/1.0.18/+download/libmemcached-1.0.18.tar.gz
    [ -f memcached-2.2.0.tgz ]||wget https://pecl.php.net/get/memcached-2.2.0.tgz
    check_ok
    tar zxvf libmemcached-1.0.18.tar.gz
    cd libmemcached-1.0.18
    ./configure --prefix=/usr/local/libmemcached  --with-memcached
    check_ok
    make && make install
    check_ok
    echo "export LD_LIBRARY_PATH=/usr/local/libmemcached/lib:\$LD_LIBRARY_PATH" >> /etc/profile.d/path.sh
    source /etc/profile.d/path.sh
    
    cd /usr/local/src
    tar zxf memcached-2.2.0.tgz
    check_ok
    cd memcached-2.2.0
    install_php_extension memcached.so
}


##function of install swoole extension module
install_php_swoolemod() 
{
    cd $install_basedir
    /bin/cp ./src/swoole-1.10.5.tgz /usr/local/src/
    cd /usr/local/src
    [ -f swoole-1.10.5.tgz ]||wget  https://pecl.php.net/get/swoole-1.10.5.tgz
    check_ok
    tar -zxf swoole-1.10.5.tgz
    check_ok
    cd swoole-1.10.5
    install_php_extension swoole.so
}


##function of install xxtea extension module
install_php_xxteamod()
{
    cd $install_basedir
    /bin/cp ./src/xxtea-1.0.11.tgz /usr/local/src/
    cd /usr/local/src
    [ -f xxtea-1.0.11.tgz ]||wget http://pecl.php.net/get/xxtea-1.0.11.tgz
    check_ok
    tar -zxf xxtea-1.0.11.tgz
    check_ok
    cd xxtea-1.0.11
    install_php_extension xxtea.so
}


##function of install xxtea extension module(default enabled, needn't execute)
install_php_mcryptmod()
{
    libmcrypt_url='http://downloads.sourceforge.net/project/mcrypt/Libmcrypt/2.5.8/libmcrypt-2.5.8.tar.gz'
    mhash_url='https://sourceforge.net/projects/mhash/files/mhash/0.9.9.9/mhash-0.9.9.9.tar.gz'
    mcrypt_url='http://downloads.sourceforge.net/project/mcrypt/MCrypt/2.6.8/mcrypt-2.6.8.tar.gz'
    cd $install_basedir
    /bin/cp ./src/libmcrypt-2.5.8.tar.gz /usr/local/src/
    /bin/cp ./src/mhash-0.9.9.9.tar.gz /usr/local/src/
    /bin/cp ./src/mcrypt-2.6.8.tar.gz /usr/local/src/
	
    # 安装libmcrypt
    cd /usr/local/src
    [ -f libmcrypt-2.5.8.tar.gz ]|| wget ${libmcrypt_url}
    tar -xzvf libmcrypt-2.5.8.tar.gz
    cd libmcrypt-2.5.8
    check_ok
    ./configure
    check_ok
	make
    check_ok
    make install
    check_ok

    # 安装mhash
    cd /usr/local/src
    [ -f mhash-0.9.9.9.tar.gz ]|| wget mhash_url
    tar -zxf mhash-0.9.9.9.tar.gz
    cd mhash-0.9.9.9
    check_ok
    ./configure
    check_ok
	make
    check_ok
    make install
    check_ok
	
    # 安装mcrypt
    export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
    cd /usr/local/src
    [ -f mcrypt-2.6.8.tar.gz ]|| wget mcrypt_url
    tar -xzvf mcrypt-2.6.8.tar.gz
    cd mcrypt-2.6.8
    check_ok
    ./configure
    check_ok
    make && make install
    check_ok
	
    # 安装Mcrypt的PHP扩展
	# 版本号php-5.6.39 需和install_phpfpm 函数中安装的保持一致
    cd /usr/local/src/php-5.6.39/ext/mcrypt
    install_php_extension mcrypt.so
}
