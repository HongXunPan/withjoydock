#!/bin/bash
#Last change time: 2018-5-25

install_project_dependencies(){
    current_dir="$(cd $(dirname $0) && /usr/bin/pwd)"
    install_basedir="${current_dir%/*}/src/"   #库文件存放目录

    yum install -y subversion psmisc
    cp ${install_basedir}so.tgz /usr/local/src/
    cd /usr/local/src/
    tar -zxf so.tgz
    cd so/*  /usr/local/lib/
    echo "/usr/local/lib" >> /etc/ld.so.conf
    /sbin/ldconfig
}