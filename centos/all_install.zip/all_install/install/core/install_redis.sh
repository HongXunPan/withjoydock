#!/bin/bash

##function of intsall redis.
install_redis() 
{
    cd $install_basedir
    echo -e "\033[36mStart installing redis...\033[0m"
    ##创建redis用户
    if ! grep '^$redis_user:' /etc/passwd
    then
        useradd -s /sbin/nologin $redis_user
    fi
    #下载redis，编译安装
    /bin/cp ./src/redis-4.0.9.tar.gz /usr/local/src/
    cd  /usr/local/src
    [ -f redis-4.0.9.tar.gz ] || wget -c http://download.redis.io/releases/redis-4.0.9.tar.gz
    tar zxf redis-4.0.9.tar.gz
    check_ok
    [ -d /usr/local/redis ] && mv /usr/local/redis /usr/local/redis_`date +%s`
    cd  redis-4.0.9
    make
    check_ok
    make install  PREFIX=$redis_install_dir
    check_ok
    mkdir ${redis_install_dir}/{etc,var}

    # 配置第1个redis主配置文件
    /bin/cp ${install_basedir}conf/redis.conf ${redis_install_dir}/etc/

    old_maxmemory=`grep 'maxmemory ' ${install_basedir}conf/redis.conf |awk '{print $2}'`
    # echo $old_maxmemory
    sed -i -e "s/127.0.0.1/${db_addr}/g" -e "s/${old_maxmemory}/${mem_size}/g" \
	-e "s#${redis_install}#${redis_install_dir}#g" ${redis_install_dir}/etc/redis.conf
    # sed -i "19s/redis..2017/$redis_ps/g" /usr/local/redis/etc/redis.conf
	
    # 配置第1个redis启动脚本
    [ -f "$redis_init_file" ] && mv $redis_init_file ${redis_init_file}_`date +%s`
    /bin/cp ${install_basedir}conf/redis $redis_init_file
	
	# 修改第1个redis启动脚本参数
    sed -i -e "s#${redis_install}#${redis_install_dir}#g" -e "/^REDIS_USER/s/redis/${redis_user}/g" \
    -e "/lockfile/s/redis/redis_4601/" $redis_init_file
	
    chmod 777 ${redis_install_dir}/var/
    chmod 755 $redis_init_file
	chkconfig --add redis$redis_start_port
    chkconfig --level 2345 redis$redis_start_port on
    service redis$redis_start_port restart

    echo "export PATH=\$PATH:${redis_install_dir}/bin" >> /etc/profile.d/path.sh
    source /etc/profile.d/path.sh
	
	# 开始配置其他redis
	if [ ${redis_initialize_number} -gt 1 ];then
        start_number=`expr ${redis_start_port} + 1`  #默认的话是4601+1
        for i in `seq ${start_number} ${redis_end_port}`;do
            rsync -arl ${redis_install_dir}/* ${redis_install}_$i/
            sed -i -e "s/${redis_start_port}/${i}/g" \
            -e "s#${redis_install_dir}#${redis_install}_${i}/#g" ${redis_install}_$i/etc/redis.conf
		
            # 修改启动脚本参数
            cd /etc/init.d/ &&cp redis${redis_start_port} redis$i && sed -i "s/redis_${redis_start_port}/redis_${i}/g" ./redis$i
            chkconfig --add redis$i
            chkconfig --level 2345 redis$i on
            service redis$i restart
        done
    fi
    check_ok
	check_redis_status
}
