#!/bin/bash
#Author: Aaron
#Date: 2017-04-29
#Description: Centos7 测试通过安装lnmp环境的脚本

source /etc/profile

###### defined variable ######
cp_name='byebye'       #公司名称缩写
pma_web_addr='' #phpmyadmin项目所在服务器IP

# web_addr='172.31.5.154'  # 直接填写游戏服务器内网ip
# db_addr='172.31.5.155'  # 直接填写数据服务器内网ip
web_addr=$(ip a|grep inet |grep  -o '172\.[0-9.]\{5,\}/[0-9]\{2,\}\|10\.[0-9.]\{5,\}/[0-9]\{2,\}\|192\.[0-9.]\{5,\}/[0-9]\{2,\}'|awk -F '/' '{print $1}')  # 匹配获取游戏服务器内网ip
db_addr=$(ip a|grep inet |grep  -o '172\.[0-9.]\{5,\}/[0-9]\{2,\}\|10\.[0-9.]\{5,\}/[0-9]\{2,\}\|192\.[0-9.]\{5,\}/[0-9]\{2,\}'|awk -F '/' '{print $1}')   # 匹配获取数据库服务器内网ip

#php配置
php_user=www
php_install_dir='/usr/local/php'

#Nginx配置
nginx_user='www'  #nginx进程启动用户
nginx_install_dir='/usr/local/nginx'  #安装目录

# 项目域名配置
domain='www'				# 主(API)项目域名
cdn_domain=''					# cdn域名
agency_domain=''				# 代理商系统域名
h5_domain=''					# H5项目域名
backstage_domain=''	# 后台管理系统域名

# 域名ssl安装参数
ssl_domain=()					# 需要配置ssl证书的域名
# 项目多域名(不存在多个域名不需填写)
api_other_domain=()					# 主(API)项目其他域名
h5_other_domain=()				# H5项目其他域名

web_dir='/data/wwwroot/'   #项目代码web根目录
cdn_item_listen_port='80'						# cdn监听的web端口，默认值7004
cdn_item_name='cdnsource'							# cdn目录名
cdn_root_dir=${web_dir}${cdn_item_name}		# cdn项目root目录
web_item_listen_port='80'						# 主(API)项目监听端口，默认值7000
web_item_name='game_malay.conf'							# 主(API)项目目录名
web_root_dir=${web_dir}${web_item_name}		# 主(API)项目虚拟主机web根目录
agency_item_listen_port=''						# 代理商项目监听端口，默认值80
agency_item_name=''								# 代理商系统项目目录名
agency_root_dir=${web_dir}${agency_item_name}	# 代理商系统nginx虚拟主机web根目录
h5_item_listen_port=''					# H5项目监听端口，默认值7002
h5_item_name='' 						# H5项目目录名
h5_root_dir=${web_dir}${h5_item_name}	# H5项目nginx虚拟主机web根目录
backstage_item_listen_port=''							# 后台管理项目监听端口，默认值7001
backstage_item_name=''									# 后台管理项目目录名
backstage_root_dir=${web_dir}${backstage_item_name}		# 后台管理项目nginx虚拟主机web根目录


#游戏项目相关配置
gs_code_dir='/data/gameserver/'  #C++代码包部署目录
gs_item_name='123'  #游戏项目目录名
gs_id=''    #必填，游戏id号,定时任务传参使用

#mysql配置
mysql_conf='my_4gb.cnf'  		#需要使用的mysql配置文件
mysql_pwd='sv5cYPq9gpyfqnh'	#root用户密码
business_user='ZaqXsw123'			#项目默认业务账号
business_auth_host=${db_addr%.*}'.%'	#项目默认业务账号被授权的主机
business_pwd='S7OfQv3egeUpRHrX'		#项目默认业务账号密码

#redis配置
redis_user='redis'			# redis进程启动用户
redis_start_port='4601'		# 第一个redis启动的端口
redis_initialize_number='1'	# 需要启动的redis服务数量
redis_ps='sfgfj4hrd?414'	# redis密码(默认密码被注释)
mem_size=128mb				# 单个redis最大可使用的内存大小
redis_end_port=`expr ${redis_start_port} + ${redis_initialize_number} - 1`	# redis最大的端口号
redis_install='/usr/local/redis'
redis_install_dir="${redis_install}_$redis_start_port"						# redis服务安装路径
redis_init_file="/etc/init.d/redis$redis_start_port"						# redis启动脚本位置

#memcached配置
memcached_user='memcached'		# memcached进程启动用户
memcached_start_port='11211'	# 第一个memcached启动的端口
memcached_initialize_number='6'	# 需要启动的memcached服务数量
memcached_mem_size=128			# 单个memcached最大可使用的内存大小
memcached_end_port=`expr ${memcached_start_port} + ${memcached_initialize_number} - 1`	# memcached最大的端口号
memcached_install_dir="/usr/local/memcached"		# memcached服务安装路径
memcached_init_file="/etc/init.d/memcached${memcached_start_port}"
######  defined variable end  #######


install_basedir="$(cd $(dirname $0) && /usr/bin/pwd)"
install_basedir="${install_basedir%/*}/"
cd ${install_basedir}core

# 加载检测脚本到内存
. ./check_svc_status.sh

# 加载安装脚本函数到内存
for i in `ls ./install_*.sh`;do
    . ./$i
done

# 加载定时任务计划函数到内存
for cron_item in `ls ../cron/`;do
	. ../cron/${cron_item}
done


echo -e "\033[31m################################################################
##                                                            ##
##          \033[36mIt will install lnmp(Author：Aaron) \033[31m                ##
##                                                            ##
################################################################\033[0m"
sleep 1


##get the archive of the system,i686 or x86_64.
ar=`arch`


##if the packge installed ,then omit.
myum() 
{
    if ! rpm -qa|grep -q "^$1"
    then
        yum install -y $1
        check_ok
    else
        echo $1 already installed.
    fi
}

## install some packges.
for p in wget automake autoconf libtool gcc gcc-c++ zlib-devel libaio-devel rsync
do
    myum $p
done


while :; do
    #选择安装的环境
    echo -e "\033[36mPlease select the software package you need to install\n\n
        0  [exit]\n\n
        1  [install lnp(shufen)]\n\n    
        2  [install mrm]\n\n
        3  [install nginx]\n\n
        4  [install mysql]\n\n
        5  [install redis]\n\n
        6  [install php]\n\n
        7  [install lnp(xxtea+swoole)]\n\n
        8  [install lnmprm]\n\033[0m"
        
    read -p "Please chose which type env you install, [lnmp]:  " t
    ${t:=1}

    case $t in
      0)
        exit 0
        ;;
      1)
        install_nginx
        install_phpfpm
        install_php_redismod
        install_php_memmod
        # sfCron "$web_item_name"
        echo -e "\033[36mlnp install complete. \033[0m"
        ;;
      2)
        install_mysql
        install_redis
        install_memcached
        common_cron
        db_cron
        echo -e "\033[36mMysql+redis+memcached install complete. \033[0m"
        ;;
      3)
        install_nginx
        echo -e "\033[36mnginx install complete. \033[0m"
        ;;
      4)
        install_mysql
        echo -e "\033[36mmysql install complete. \033[0m"
        ;;
      5)
        install_redis
        echo -e "\033[36mredis install complete. \033[0m"
        ;;
      6)
        install_phpfpm
        echo -e "\033[36mphp install complete. \033[0m"
        ;;

      7)
        install_nginx
        install_phpfpm
        install_php_redismod
        install_php_memmod
        install_php_swoolemod
        install_php_xxteamod
        common_cron
        nginx_web_cron
        # xc_gameCron "$web_item_name" "$gs_id"
        install_nodejs
        jh_gameCron "$web_item_name" "$gs_id"
        echo -e "\033[36mlnmp+nodejs install complete. \033[0m"
        ;;
      8)
        install_mysql
        install_nginx
        install_phpfpm
        install_redis
        install_memcached
        install_php_redismod
        install_php_memmod
        install_php_swoolemod
        install_php_xxteamod
        common_cron
        db_cron
        nginx_web_cron
        # xc_gameCron "$web_item_name" "$gs_id"
        install_nodejs
        jh_gameCron "$web_item_name" "$gs_id"
        echo -e "\033[36mlnmp+nodejs+redis+memcached install complete. \033[0m"
        ;;
      *)
        echo -e "\033[31mError\nPlease follow the prompts to enter one of 1 to 7 ！！\033[0m"
        ;;
    esac
done
