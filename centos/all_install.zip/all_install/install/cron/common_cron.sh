#!/bin/bash
# Description: Common scheduled tasks

common_cron(){
    echo "0 */2 * * * sync && /usr/bin/echo 3 > /proc/sys/vm/drop_caches > /dev/null 2>&1 &" >> /var/spool/cron/root
}
