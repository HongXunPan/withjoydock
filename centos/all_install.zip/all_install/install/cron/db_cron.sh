#!/bin/bash

db_cron(){
    echo "#Ansible: db_log_backup" >> /var/spool/cron/root
    echo "0 0 * * * /bin/bash /usr/local/sbin/db_log_backup.sh > /dev/null 2>&1 &" >> /var/spool/cron/root
    echo "#Ansible: gs_mysql_backup" >> /var/spool/cron/root
    echo "0 0 * * * /bin/bash /usr/local/sbin/gs_mysql_backup.sh > /dev/null 2>&1 &" >> /var/spool/cron/root
	cd ${install_basedir}script
    cp ./{db_log_backup,gs_mysql_backup}.sh /usr/local/sbin/
	cp ./import_mysql.py  /usr/local/sbin/
    sed -i "s/^mysqlpasswd=.*/mysqlpasswd=${mysql_pwd}/" /usr/local/sbin/gs_mysql_backup.sh
    sed -i "s/^pwd = .*/pwd = '${mysql_pwd}'/" /usr/local/sbin/import_mysql.py
	chmod 600 /usr/local/sbin/import_mysql.py
	chmod 600 /usr/local/sbin/gs_mysql_backup.sh
}