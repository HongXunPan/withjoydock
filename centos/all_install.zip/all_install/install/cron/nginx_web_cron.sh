#!/bin/bash

nginx_web_cron(){
    # nginx日志切割
    echo "#Ansible: gs_log_backup" >> /var/spool/cron/root
    echo "0 0 * * * /bin/bash /usr/local/sbin/gs_log_backup.sh > /dev/null 2>&1 &" >> /var/spool/cron/root
	cd ${install_basedir}script
    cp ./gs_log_backup.sh /usr/local/sbin/
    cp ./statistic_process.py /usr/local/sbin/
}
