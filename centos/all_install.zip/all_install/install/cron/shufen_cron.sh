#!/bin/bash
#date: 2017-11-15

sfCron(){
    project="$1"
    cron_time='20 1 * * *'
    cmd="/bin/bash /data/wwwroot/${project}/sh/cron_compute_daily_info.sh"
    cmd_end='> /dev/null 2>&1 &'
    echo "#Ansible: shufen_cron" >> /var/spool/cron/www
    echo "${cron_time} ${cmd} ${cmd_end}" >> /var/spool/cron/www
} 
