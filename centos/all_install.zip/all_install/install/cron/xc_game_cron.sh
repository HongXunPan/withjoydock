xc_gameCron(){
    project="$1"
    game_id="$2"
    cron_time='*/1 * * * *'
    cmd="/usr/local/php/bin/php /data/wwwroot/${project}/crontab/core.php ${game_id}"
    cmd_end='> /dev/null 2>&1 &'
    echo -e "#Ansible: ${project}-queue" >> /var/spool/cron/www
    echo -e "${cron_time} ${cmd} ${cmd_end}" >> /var/spool/cron/www
}