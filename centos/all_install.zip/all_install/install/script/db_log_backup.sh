#!bin/bash
#    Author: Aaron
#    Time：
#    Description: 针对装有redis的数据库服务器的日志切割

###### default variable ######
yesterday=`date -d "-1 day" +%F`

redis_start_port=4601
redis_end_port=4606
redis_log_dir=/usr/local/redis/var/      #redis日志所在目录
redis_backup_dir=/data/backup/redis_log/ #redis日志备份目录
redis_backup_date=7 #备份保存时间

#redis日志切割函数,需要传2个参数
redis_logs_cut()
{
    [ -d $2 ] || mkdir -p $2
    for i in `seq ${redis_start_port} ${redis_end_port}`;do
        redis_log_dir=`echo ${redis_log_dir}|awk -F '/var' '{print $1}'`"_"${i}
        redis_log_file="${redis_log_dir}/var/redis_${i}.log"
        
        cat ${redis_log_file} > ${2}${yesterday}_redis_${i}.log
        > ${redis_log_file}
    done
    cd $2
    gzip -f *.log

    #自动清除7天前的备份
    find $2 -mtime +${redis_backup_date} -exec rm -f {} \;
}

redis_log_cut()
{
    [ -d $2 ] || mkdir -p $2
    redis_log_file="${redis_log_dir}redis.log"
    
    cat ${redis_log_file} > ${2}${yesterday}_redis.log
    > ${redis_log_file}
    done
    cd $2
    gzip -f *.log

    #自动清除7天前的备份
    find $2 -mtime +${redis_backup_date} -exec rm -f {} \;
}


main(){
    redis_process_num=`netstat -lnpt|grep 'redis' |wc -l`
    if [ "$redis_process_num" -gt 1 ];then
        redis_logs_cut $redis_log_dir $redis_backup_dir
    else
        redis_log_cut $redis_log_dir $redis_backup_dir
}

main

