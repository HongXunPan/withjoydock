#!/usr/bin/env python
# -*- encoding:utf-8 -*-
# Author:
# Date: 2019-01-08
# Description：
import re
import sys
import time
import logging
from os import listdir as os_listdir
from os import path as os_path
from os import popen
from os import system as os_system


# 写日志
def logger(file_name, level='DEBUG'):
    _logger = logging.getLogger()
    _logger.setLevel(getattr(logging, level))

    # 创建一个handler，用于写入日志文件
    fh = logging.FileHandler(filename=file_name, mode='a', encoding='utf-8')

    # 定义handler的输出格式formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)

    # 给logger添加handler
    logger.addHandler(fh)

    return _logger


# 将app.js这种进程单独拿出来判断{"process_file_name": "进程文件", "dirname":"目录名"}
def monitor_other_process(path, process_name_dict):
    p_name = process_name_dict['process_file_name']
    p_dirname = process_name_dict['dirname']
    project_name_list = os_listdir(path)
    p_number = len(project_name_list)
    cmd = "ps aux|grep {}|grep -v grep|wc -l".format(p_name)
    c_number = int(popen(cmd).read().strip())

    if p_number != c_number:
        print("\033[31m{}\t{}进程出现异常,尝试重启\033[0m".format(time.strftime("%Y-%m-%d  %X"), p_name))
        for project_name in project_name_list:
            start_p_cmd = os_path.join(path, project_name, p_dirname, 'start.sh')
            popen(start_p_cmd)
    else:
        print("\033[36m{}\t{}进程状态[OK],数量[{}]\033[0m".format(time.strftime("%Y-%m-%d  %X"), p_name, p_number))

    return True


# 针对游戏项目，过滤出进程文件名的函数
def filter_process_file(file_list):
    """
    :param file_list:
    :return: process_file_name
    """
    regex = re.compile('^([a-zA-Z]+(?!\.sh$|\.).)*$')
    _new_file_list = []
    for f_name in file_list:
        if regex.findall(f_name):
            _new_file_list.append(f_name)

    # print("\033[36m get the process filename --> {}\033[0m".format(_new_file_list))
    if len(_new_file_list) != 1:
        print("\033[31m获取进程文件出错,获取到多个文件:{} \n\033[0m".format(_new_file_list))
        sys.exit()
    process_file_name = _new_file_list[0]

    return process_file_name


# 针对游戏项目的启动脚本收集默认启动数量
def collect_project_number(file_name):
    """
    :param file_name: 启动脚本文件名；用作收集进程默认数量参数
    :param p_name: 启动命令的第1段；用来区分特殊进程的默认数量获取方式
    :return: int
    """
    process_number = 0

    with open(file_name) as fd:
        for i in fd:
            # 匹配并统计以$filepath 开头的行数
            if i.strip().startswith('$filepath'):
                process_number += 1

    return process_number


def handler(pjt_p_info, pj_name, path, p_father_dir, start_f_name):
    start_file_father_dir_path = os_path.join(path, p_father_dir)
    # 正则匹配去除目录和 .sh结尾的文件
    _file_list = [i for i in os_listdir(start_file_father_dir_path) if
                  os_path.isfile(os_path.join(start_file_father_dir_path, i))]
    # 进程真实启动文件名
    process_file_name = filter_process_file(_file_list)
    start_file_path = os_path.join(start_file_father_dir_path, start_f_name)
    start_cmd = "cd {} && ./{}".format(start_file_father_dir_path, start_f_name)
    p_number = collect_project_number(start_file_path)  # 获取进程默认启动数量

    pjt_p_info[pj_name][process_file_name] = {}
    pjt_p_info[pj_name][process_file_name]["start_cmd"] = start_cmd
    pjt_p_info[pj_name][process_file_name]["number"] = p_number

    return pjt_p_info


# 收集进程默认信息
def collect_project_process_info(g_code_path, process_dirname_list, process_mode):
    """
    :param g_code_path:
    :param process_dirname_list:
    :param process_mode: {"special": {"目录名": {"process_file_name": "存放不好通过处理获取的进程名", children_dir_list":["AllocServer","GameServer"，"通过有无判断是否为游戏玩法目录"], "start_file_father_dir":'./bin'}},
                        "common":{"start_file_father_dir":'bin'}}
    :return:{"项目1": {"进程1": {"start_cmd": "启动命令", "number": "默认启动的进程数量"},},}
    """

    project_process_info = {}
    project_path_list = []
    # process_name = ''   #进程名
    # start_file_path = '' #启动文件路径

    # 所有项目名称
    project_name_list = os_listdir(g_code_path)
    project_quantity = len(project_name_list)
    print("\033[36m{}\t{}下项目有{},共{}\033[0m".format(time.strftime("%Y-%m-%d  %X"), g_code_path,
                                                 project_name_list, project_quantity))

    # 拼接所有项目路径
    for pj_name in project_name_list:
        project_process_info[pj_name] = {}
        pj_path = os_path.join(g_code_path, pj_name)
        project_path_list.append(pj_path)
        # print("\033[36m 开始拼接{} 项目启动文件路径\n\033[0m".format(pj_path))

        # 拼接启动文件位置
        for process_dirname in process_dirname_list:

            if process_dirname not in process_mode["special"]:
                _p_path = os_path.join(pj_path, process_dirname)
                process_father_dir = process_mode["common"]["start_file_father_dir"]
                start_file_name = process_mode["common"]["start_file"]
                project_process_info = handler(pjt_p_info=project_process_info, pj_name=pj_name, path=_p_path,
                                               p_father_dir=process_father_dir, start_f_name=start_file_name)
                continue

            process_info = process_mode["special"][process_dirname]
            children_dir_list = process_info.get("children_dir_list", None)
            start_file_father_dir = process_info["start_file_father_dir"]

            if children_dir_list:  # 游戏玩法目录处理
                game_path = os_path.join(pj_path, process_dirname)
                game_type_path_list = [os_path.join(game_path, i) for i in os_listdir(game_path)
                                       if os_path.isdir(os_path.join(game_path, i))]
                for game_type_path in game_type_path_list:
                    for children_dir in children_dir_list:
                        _p_path = os_path.join(game_type_path, children_dir)
                        process_father_dir = start_file_father_dir
                        start_file_name = process_info["start_file"]
                        project_process_info = handler(pjt_p_info=project_process_info, pj_name=pj_name, path=_p_path,
                                                       p_father_dir=process_father_dir,
                                                       start_f_name=start_file_name)
                continue

            _p_path = os_path.join(pj_path, process_dirname)
            process_father_dir = start_file_father_dir
            start_file_name = process_info["start_file"]
            project_process_info = handler(pjt_p_info=project_process_info, pj_name=pj_name, path=_p_path,
                                           p_father_dir=process_father_dir, start_f_name=start_file_name)

    # print("\033[36m \n\033[0m")

    return project_process_info
    """
    :param g_code_path:
    :param process_dirname_list:
    :param process_mode: {"special": {"目录名": {"process_file_name": "存放不好通过处理获取的进程名", children_dir_list":["AllocServer","GameServer"，"通过有无判断是否为游戏玩法目录"], "start_file_father_dir":'./bin'}},
                        "common":{"start_file_father_dir":'bin'}}
    :return:{"项目1": {"进程1": {"start_cmd": "启动命令", "number": "默认启动的进程数量"},},}
    """


    project_process_info = {}
    project_path_list = []
    # process_name = ''   #进程名
    # start_file_path = '' #启动文件路径

    # 所有项目名称
    project_name_list = os_listdir(g_code_path)
    project_quantity = len(project_name_list)
    print("\033[36m{}\t{}下项目有{},共{}\033[0m".format(time.strftime("%Y-%m-%d  %X"), g_code_path,
                                                 project_name_list, project_quantity))

    # 拼接所有项目路径
    for pj_name in project_name_list:
        project_process_info[pj_name] = {}
        pj_path = os_path.join(g_code_path, pj_name)
        project_path_list.append(pj_path)
        # print("\033[36m 开始拼接{} 项目启动文件路径\n\033[0m".format(pj_path))

        # 拼接启动文件位置
        for process_dirname in process_dirname_list:

            if process_dirname not in process_mode["special"]:
                # 启动文件所在目录
                start_file_father_dir_path = os_path.join(pj_path, process_dirname,
                                                          process_mode["common"]["start_file_father_dir"])
                # 正则匹配去除目录和 .sh结尾的文件
                _file_list = [i for i in os_listdir(start_file_father_dir_path) if
                              os_path.isfile(os_path.join(start_file_father_dir_path, i))]
                # 进程真实启动文件
                process_file_name = filter_process_file(_file_list)
                start_file_path = os_path.join(start_file_father_dir_path, process_mode["common"]["start_file"])
                start_cmd = "cd {} && ./{}".format(start_file_father_dir_path,
                                                   process_mode["common"]["start_file"])
                p_number = collect_project_number(start_file_path)  # 获取进程默认启动数量

                project_process_info[pj_name][process_file_name] = {}
                project_process_info[pj_name][process_file_name]["start_cmd"] = start_cmd
                project_process_info[pj_name][process_file_name]["number"] = p_number
                continue

            process_info = process_mode["special"][process_dirname]
            children_dir_list = process_info.get("children_dir_list", None)
            start_file_father_dir = process_info["start_file_father_dir"]

            if children_dir_list: # 游戏玩法目录处理
                game_path = os_path.join(pj_path, process_dirname)
                game_type_path_list = [ os_path.join(game_path, i) for i in os_listdir(game_path) if os_path.isdir(os_path.join(game_path, i)) ]
                for game_type_path in game_type_path_list:
                    for children_dir in children_dir_list:
                        start_file_father_dir_path = os_path.join(game_type_path,children_dir,
                                                                  start_file_father_dir)
                        # 正则匹配去除目录和 .sh结尾的文件
                        _file_list = [i for i in os_listdir(start_file_father_dir_path) if
                                      os_path.isfile(os_path.join(start_file_father_dir_path, i))]
                        process_file_name = filter_process_file(_file_list)
                        start_file_path = os_path.join(start_file_father_dir_path, process_info["start_file"])
                        start_cmd = "cd {} && ./{}".format(start_file_father_dir_path,
                                                           process_info["start_file"])
                        p_number = collect_project_number(start_file_path)  # 获取进程默认启动数量

                        project_process_info[pj_name][process_file_name] = {}
                        project_process_info[pj_name][process_file_name]["start_cmd"] = start_cmd
                        project_process_info[pj_name][process_file_name]["number"] = p_number
                continue

            start_file_father_dir_path = os_path.join(pj_path, process_dirname,
                                                      start_file_father_dir)
            # 正则匹配去除目录和 .sh结尾的文件
            _file_list = [i for i in os_listdir(start_file_father_dir_path) if
                          os_path.isfile(os_path.join(start_file_father_dir_path, i))]
            process_file_name = filter_process_file(_file_list)
            start_file_path = os_path.join(start_file_father_dir_path, process_info["start_file"])
            start_cmd = "cd {} && ./{}".format(start_file_father_dir_path,
                                               process_info["start_file"])
            p_number = collect_project_number(start_file_path)  # 获取进程默认启动数量

            project_process_info[pj_name][process_file_name] = {}
            project_process_info[pj_name][process_file_name]["start_cmd"] = start_cmd
            project_process_info[pj_name][process_file_name]["number"] = p_number


    # print("\033[36m \n\033[0m")

    return project_process_info


# 统计所有游戏项目当前游戏进程(多出bash进程)
def collect_game_process(path,):
    """
    :param path:
    :return: process_info_dict = {项目名:{进程名:数量},...}
    有可能获取多
    """
    process_info_dict = {}
    project_name_list = os_listdir(path)

    cmd = 'ps aux |grep %s|grep -v grep' % path
    for project_name in project_name_list:
        process_info_dict[project_name] = {}

        p_list = popen(cmd).read().strip().split('\n')
        if p_list:
            for line in p_list:
                process_info_list = line.split()
                process_name = process_info_list[10].split('/')[-1]
                if process_name in process_info_dict[project_name]:
                    process_info_dict[project_name][process_name] += 1
                else:
                    process_info_dict[project_name][process_name] = 1


    return process_info_dict


# 字典比较
def compare_dict(defalut_dict, new_dict, difference={}):
    """
    :param defalut_dict: {"项目名": {"进程名":{"start_cmd":"xxxx", "number": "数量",}, }, ...}
    :param new_dict: {"项目名": {"进程名": "数量"}, ...}
    :return: {"项目名": {"进程名":{"start_cmd":"xxxx", "number": "数量",}, }, ...}
    """

    for k1 in defalut_dict.keys():
        # print(k1)
        if k1 not in new_dict:
            difference[k1] = defalut_dict[k1]
            continue
        else:
            difference[k1] = {}

        for k2 in defalut_dict[k1].keys():

            # print(k2, defalut_number ,c_number)
            if k2 not in new_dict[k1]:
                difference[k1][k2] = defalut_dict[k1][k2]
                continue

            defalut_number = defalut_dict[k1][k2]["number"]
            c_number = new_dict[k1][k2]
            if defalut_number != c_number:
                difference[k1][k2] = defalut_dict[k1][k2]

    return difference


# 检测指定名称的进程数量
def process_number_check(project_p_info, pj_name, p_name):
    cmd = "ps aux|grep {}|grep -v grep|wc -l".format(p_name)
    p_number = int(popen(cmd).read().strip())
    default_p_number = project_p_info[pj_name][p_name].get("number", 0)
    if not default_p_number:
        print("\033[31m{}\t{}进程数量获取异常,无法检测重启后数量\033[0m")
        return

    if default_p_number != p_number:
        return
    print("\033[36m{}\t{}进程当前数量{}\033[0m".format(time.strftime("%Y-%m-%d  %X"), p_name, p_number))
    return True


# 执行启动命令
def start_process(process_info):
    if not process_info:
        print("\033[36m{}\t所有进程状态[OK],不用重启\033[0m".format(time.strftime("%Y-%m-%d  %X")))
        return True

    for pj_name in process_info:
        for p_name in process_info[pj_name]:
            start_cmd = process_info[pj_name][p_name].get("start_cmd", None)
            if not start_cmd:
                print("\033[31m{}\t{}进程没有重启命令,重启失败\033[0m".format(time.strftime("%Y-%m-%d  %X"), p_name))
            else:
                print("\033[36m{}\t重启命令:{}\033[0m".format(time.strftime("%Y-%m-%d  %X"), start_cmd))
                popen(start_cmd)
                #print(popen("id").read())
                #os_system("id")
                print("\033[36m{}\t{}进程尝试重启完成\033[0m".format(time.strftime("%Y-%m-%d  %X"), p_name))
                res = process_number_check(process_info, pj_name, p_name)
                message = "\033[36m{}\t{}数量检测[OK],重启成功\033[0m".format(time.strftime("%Y-%m-%d  %X"), p_name) if res else \
                    "\033[31m{}\t{}状态检测[Error],重启失败\033[0m".format(time.strftime("%Y-%m-%d  %X"), p_name)
                print(message)
    return True


def process_healing(g_code_path, p_dirname_list, p_mode, special_p_info):
    pj_process_info = collect_project_process_info(g_code_path=g_code_path, process_dirname_list=p_dirname_list, process_mode=p_mode)
    #print("pj_process_info=%s" % pj_process_info)
    c_pj_process_info = collect_game_process(g_code_path)
    #print("c_pj_process_info=%s" % c_pj_process_info)

    monitor_other_process(g_code_path, special_p_info)
    need_start_process_info = compare_dict(pj_process_info, c_pj_process_info)
    start_process(need_start_process_info)


if __name__ == "__main__":
    start_time = time.time()

    # 预定义参数
    game_code_path = '/data/gameserver/'
    process_dirname_list = [
        'Games',
        'Dispatch',
        'Access',
        'UserServer',
        'CoinCacheServer',
        'PhpAgent',
        'LogServer',
        'RobotServer',
    ]
    process_mode = {
        "special": {
            "Dispatch": {
                "start_file_father_dir": "bin",
                "start_file": "start.sh",
            },
            "Access": {
                "start_file_father_dir": "bin",
                "start_file": "start.sh",
            },
            "Games": {
                "children_dir_list": ["AllocServer", "GameServer"],
                "start_file_father_dir": "bin",
                "start_file": "start.sh",
            },
        },
        "common": {
            "start_file_father_dir": "bin",
            "start_file": "start.sh",
        },
    }
    special_process_info = {"process_file_name": "app.js", "dirname": "ProxyServer", }
    process_healing(g_code_path=game_code_path, p_dirname_list=process_dirname_list,
                    p_mode=process_mode, special_p_info=special_process_info)
    """
        pj_process_info = collect_project_process_info(g_code_path=game_code_path,
                                                       process_dirname_list=process_dirname_list, process_mode=process_mode)
        c_pj_process_info = collect_game_process(game_code_path)
        monitor_other_process(game_code_path, special_process_info)
        need_start_process_info = compare_dict(pj_process_info, c_pj_process_info)
        start_process(need_start_process_info)


        # 测试打印Debug信息
        total_p_number = 0
        c_total_p_number = 0
        for k1 in pj_process_info:
            for k2 in pj_process_info[k1]:
                total_p_number += pj_process_info[k1][k2]["number"]

        for k1 in c_pj_process_info:
            for k2 in c_pj_process_info[k1]:
                c_total_p_number += c_pj_process_info[k1][k2]
        print("\033[36m游戏项目默认信息: {}\n进程总数{}\033[0m".format(pj_process_info,len(pj_process_info.keys()), total_p_number))
        print("\033[36m游戏进程当前信息: {}\n进程总数{}\033[0m".format(c_pj_process_info, c_total_p_number))
        print(need_start_process_info)
    """

    print("{}\t检测完毕,耗时: {}".format(time.strftime("%Y-%m-%d  %X"), time.time() - start_time))
