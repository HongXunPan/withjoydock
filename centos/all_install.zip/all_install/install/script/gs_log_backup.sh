#!bin/bash
#    Author: Aaron
#    Time：2017/5/10
#针对装有nginx和php的游戏服务器的日志切割

###### default variable ######
yesterday=`date -d "-1 day" +%F`
#日志路径
monitor=/data/scripts/monlog/      #监控系统日志路径 
nginx_log_dir=/usr/local/nginx/logs/      #nginx日志所在目录
php_log_dir=/usr/local/php/var/log/
#备份目录
nginx_backup_dir=/data/backup/nginx_log/  #nginx日志备份目录
php_backup_dir=/data/backup/php_log/      #php日志备份目录
#命令
nginx_command='/etc/init.d/nginx'  #nginx日志移除后，使用该命令自动生成
option=reload  #nginx命令选项
########end##############

#日志切割函数，需要传2个参数
log_rotate()
{
    [ -d $2 ] || mkdir -p $2
    for i in `ls $1|grep -Ev "*.pid|error|*.rdb"`;do
        mv ${1}$i  ${2}${yesterday}_$i
    done

    $3 $4
    cd $2
    gzip -f *.log

    #自动清除15天前的备份
    find $2 -mtime +15 -exec rm -f {} \;
}

#redis日志切割函数,需要传2个参数
cat_log_rotate()
{
    [ -d $2 ] || mkdir -p $2
    for i in `ls $1|grep -Ev "*.pid|error|*.rdb"`;do
        cat ${1}$i > ${2}${yesterday}_$i
        > ${1}$i
    done
    cd $2
    gzip -f *.log
    
    #自动清除15天前的备份
    find $2 -mtime +15 -exec rm -f {} \;
}

cat_log_rotate $php_log_dir $php_backup_dir
log_rotate $nginx_log_dir $nginx_backup_dir $nginx_command $option
#find $monitor -mtime +30|grep -vw "$monitor"|xargs rm -rf
