#!/bin/bash
#    Author: Aaron
#    Time：2017/5/10
#    description: Backup for game database server

source /etc/profile
###### default variable ######
host=$(route -n|awk '/^0\.0\.0\.0/{print $NF}'|sort -u|head -n 1|xargs ifconfig |grep -w 'inet'|awk '{print $2}')
dates=`date +"%Y-%m-%d-%H-%M-%S"`
backup_dir=/data/backup/mysql/log
db_name=${backup_dir}/databases.txt
backup_log=${backup_dir}/mysqldump.txt

#数据库用户相关信息
user=root
hostname='localhost'
mysqlpasswd='sv5cYPq9gpyfqnh'


if [ ! -d "$backup_dir" ]
then
      mkdir -p $backup_dir
fi

mysql -h$hostname -u$user -p$mysqlpasswd -e "show databases" 2>/dev/null | grep -Ev "ceshi|tes|Database|information_schema|mysql|test|performance_schema" > $db_name

for i in `cat $db_name`
do
    mysqldump -h$hostname -u$user -p$mysqlpasswd --skip-lock-tables $i > $backup_dir/${i}_$dates.sql 2>/dev/null
    if [ $? -eq 0 ];then
        echo -e "\033[36m$dates database $i backup ok\033[0m" >> $backup_log
    else
        _msg="\033[31m$dates database $i backup fail\033[0m"
	/usr/local/bin/sendEmail -f fanzc@126.com -t aaronlm@126.com -s smtp.sendgrid.net:587 \
        -o message-content-type=html -o message-charset=utf8 \
        -xu fanzc@126.com -xp fanzhichao112900 \
        -u "监控中心" -m "$_msg" -o tls=no
        echo -e "$_msg" >> $backup_log
        exit 1
    fi
done
cd ${backup_dir%/*}
tar  -zcf ${host}_backup_${dates}.tgz ${backup_dir##*/} && find  ./${backup_dir##*/} -name "*.sql" -exec rm -f {} \;
find ./ -type f -mtime +7 -exec rm -f {} \;
echo -e "################ $dates ################\n" >> $backup_log
