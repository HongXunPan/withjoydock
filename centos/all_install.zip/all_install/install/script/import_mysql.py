﻿#!/usr/bin/env python
#encoding:utf-8
import os
import shutil
import tarfile

connect_host = '127.0.0.1'
port = '3306'
user = 'root'
pwd = ""
option = '--default-character-set=utf8mb4'
dbfile_dir = '/data/'
db_file_name = ''
db_file_path = os.path.join(dbfile_dir, db_file_name)
#print(os.listdir('./'))

#解压sql文件
if not os.path.exists(os.path.join(dbfile_dir,'log')):
    tar = tarfile.open(db_file_path,"r:gz")
    tar.extractall(path=dbfile_dir)
    tar.close()

os.chdir(os.path.join(dbfile_dir,'log'))
list_dirs = os.listdir('./')
list_dirs.remove('mysqldump.txt')
list_dirs.remove('databases.txt')
#print(list_dirs)
#print(len(list_dirs))

#创建库并导入数据
import_successful_list = []
import_failed_list = []

#if not list_dirs:
#   # 获取连接的mysql 存在的所有 database；建议只在要删除当前所有库的时候去掉注释
#    database_list = os.popen('mysql  -h%s -P%s -u%s -p%s -e "show databases;"|grep -Ev "Database|mysql|performance_schema|information_schema"' \
#    %(connect_host, port, user, pwd)).read().split()
    

for i in list_dirs:
    db_name = '_'.join(i.split('_')[:-1])
#    os.system('mysql  -h%s -P%s -u%s -p%s -e "drop database %s"' %(connect_host,user,pwd,db_name)) #删库跑路操作
    os.system('mysql  -h%s -P%s -u%s -p%s -e "create database %s"' %(connect_host, port, user, pwd, db_name))
    res = os.system('mysql  -h%s -P%s -u%s -p%s %s %s < %s' %(connect_host,port, user, pwd, option, db_name, i))
    if res:
        import_failed_list.append(db_name)
    import_successful_list.append(db_name)

#清除残余的目录
shutil.rmtree('%slog'% dbfile_dir)

if import_failed_list and import_successful_list:
    print("%s 这%s个库导入成功;\n%s  %s个库导入失败,请尝试再次导入" % (import_successful_list,len(import_successful_list),import_failed_list,len(import_failed_list)))
elif import_failed_list:
    print("{}这{}个库导入失败,请尝试再次导入".format(import_failed_list,len(import_failed_list)))
else:
    print("{}这{}个库导入成功.".format(import_successful_list,len(import_successful_list)))
