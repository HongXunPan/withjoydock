#!/usr/bin/env python
#-*-encoding:utf-8-*-
#Description: Statistics the name and number of the game process.

from os import popen
gs_process_user = 'server'  #游戏进程用户

def statistics_process(user):
    process_info_dict = {}
    #cmd = 'top -bn 1 |grep server'
    cmd = 'ps aux |grep %s|grep -v grep' % user
    for line in popen(cmd).read().strip().split('\n'):
        process_info_list = line.split()
        # if process_info[0] = gs_process_user:
        process_name = process_info_list[10].split('/')[-1]
        if process_name in process_info_dict:
            process_info_dict[process_name] += 1
        else:
            process_info_dict[process_name] = 1
            
    process_list = sorted(process_info_dict.iteritems())
    
    print("\033[36m需要监控的进程名称有%d个\n\033[0m" % (len(process_info_dict)))
    for p in process_list:
        print "\033[36m进程:{:<32}数量:{}\033[0m".format(p[0], p[1])
    return process_info_dict

if __name__ == '__main__':
    statistics_process(gs_process_user)