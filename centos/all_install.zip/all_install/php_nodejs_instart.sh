#!/bin/bash

##function of intsall node.js
install_nodejs() 
{
    cd /usr/local/src
    [ -f node-v10.14.2-linux-x64.tar.xz ] || wget https://npm.taobao.org/mirrors/node/v12.16.1/node-v12.16.1-linux-x64.tar.xz
    tar xf node-v12.16.1-linux-x64.tar.xz
    mv node-v12.16.1-linux-x64 ../nodejs
    echo "export PATH=\$PATH:/usr/local/nodejs/bin" >> /etc/profile.d/path.sh
}