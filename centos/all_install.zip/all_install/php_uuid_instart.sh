#!/bin/bash
#新装的PHP需要重启服务器
yum install -y libuuid-devel uuid uuid-devel e2fsprogs-devel
cd /usr/local/php
wget http://pecl.php.net/get/uuid-1.0.4.tgz
tar -zxf uuid-1.0.4.tgz
rm -f uuid*.tgz
cd /usr/local/php/uuid-1.0.4
phpize && \
./configure --with-php-config=/usr/local/php/bin/php-config
make && make install
echo 'extension = uuid.so' >>/usr/local/php/etc/php.ini
